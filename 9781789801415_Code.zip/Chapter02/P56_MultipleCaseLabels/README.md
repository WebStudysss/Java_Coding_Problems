# Multiple case labels
Write a snippet of code for exemplifying the JDK 12 **switch** with multiple **case** labels.
