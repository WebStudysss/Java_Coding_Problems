package modern.challenge;

public class SportType {
    
}
