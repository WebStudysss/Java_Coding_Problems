# Writing an immutable class
Write a program that represents an immutable class.