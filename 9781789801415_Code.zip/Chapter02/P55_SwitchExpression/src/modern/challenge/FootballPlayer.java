package modern.challenge;

public class FootballPlayer extends Player {    
}
