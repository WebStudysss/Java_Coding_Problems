# Find the first non-repeated character
Write a program that returns the first non-repeated character from a given string.