# Fused Multiply Add (FMA)
Write a program that takes three **float**/**double** **a**, **b** and **c** and computes the **a * b + c** on an efficient way.