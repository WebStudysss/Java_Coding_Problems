# Compute min and max of two numbers
Write a program that returns the minimum and maximum of two numbers.