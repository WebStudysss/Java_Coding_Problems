# Find the character with the most appearances
Write a program that finds the character with the most appearances in the given string.