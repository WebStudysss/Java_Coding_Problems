# Division and modulo of unsigned values
Write a program that computes division and modulo of the given unsigned value.