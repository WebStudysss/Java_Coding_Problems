# Converting a collection into an array
Write a program that converts a collection into an array.
