# Creating a Stream from an array
Write a program that creates a **Stream** from the given array.
