# Comparing two arrays lexicographically
Write a program that compares the given arrays lexicographically.
