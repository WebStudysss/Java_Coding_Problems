# Removing from a Map
Write a program that removes from a **Map** by the given key.
