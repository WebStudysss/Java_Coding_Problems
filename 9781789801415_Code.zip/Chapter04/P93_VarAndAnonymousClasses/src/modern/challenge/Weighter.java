package modern.challenge;

public interface Weighter {
    
    int getWeight(Player player);
}
