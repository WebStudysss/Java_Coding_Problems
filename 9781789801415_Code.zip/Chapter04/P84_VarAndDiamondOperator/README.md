# Combining LVTI and the diamond operator
Write a program that exemplify the usage of **var** with the *diamond* operator.
