# Using LVTI in compound declarations
Explain and exemplify the usage of LVTI with compound declarations.
