# LVTI can be final and effectively final
Write several snippets of code that exemplifies how LVTI can be used for **final** and *effectively final* variables.
