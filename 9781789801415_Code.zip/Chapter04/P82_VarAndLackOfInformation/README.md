# Avoid using var if the called names don't contain enough type information for humans
Provide examples where **var** should be avoided because its combination with called names causes loss of information for humans.
