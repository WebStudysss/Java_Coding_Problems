# Define a period of time using date-based values (Period) and a duration of time using time-based values (Duration)
Explain and exemplify the usage of **Period** and **Duration** APIs.
