# LocalDateTime from LocalDate and LocalTime
Write a program that builds a **LocalDateTime** from **LocalDate** and **LocalTime**. Combine date and time in a single **LocalDateTime** object.
