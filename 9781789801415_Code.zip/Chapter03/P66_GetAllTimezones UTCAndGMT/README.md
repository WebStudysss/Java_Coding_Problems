# Get all time zones with UTC and GMT
Write a program that displays all the available time zones with UTC and GMT.
