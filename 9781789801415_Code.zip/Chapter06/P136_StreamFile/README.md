# Streaming a file content
Write a program that streams the content of the given file.
