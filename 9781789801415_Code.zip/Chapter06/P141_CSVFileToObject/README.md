# Read a JSON/CSV file as Object
Write a program that reads the given JSON/CSV file as **Object** (POJO)
